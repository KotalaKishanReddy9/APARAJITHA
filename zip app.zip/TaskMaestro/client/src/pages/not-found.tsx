import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Home, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth";

export default function NotFound() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  const goHome = () => {
    if (user) {
      setLocation(user.role === "teacher" ? "/teacher/dashboard" : "/student/dashboard");
    } else {
      setLocation("/login");
    }
  };

  const goBack = () => {
    window.history.back();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-destructive/10 rounded-lg">
              <AlertCircle className="h-10 w-10 text-destructive" />
            </div>
          </div>
          <CardTitle className="text-2xl">Page Not Found</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-muted-foreground">
            The page you're looking for doesn't exist or has been moved.
          </p>
          <div className="flex gap-2 justify-center">
            <Button onClick={goBack} variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Go Back
            </Button>
            <Button onClick={goHome} size="sm">
              <Home className="h-4 w-4 mr-2" />
              {user ? "Dashboard" : "Login"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
