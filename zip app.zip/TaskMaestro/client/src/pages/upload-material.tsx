import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertMaterialSchema } from "@shared/schema";
import { ArrowLeft, Upload } from "lucide-react";

export default function UploadMaterial() {
  const [, params] = useRoute("/teacher/courses/:courseId/materials/upload");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(insertMaterialSchema),
    defaultValues: {
      courseId: params?.courseId || "",
      title: "",
      fileUrl: "",
      fileType: "",
    },
  });

  const uploadMaterialMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/materials", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses", params?.courseId, "materials"] });
      toast({
        title: "Material uploaded",
        description: "Your material has been uploaded successfully",
      });
      setLocation(`/teacher/courses/${params?.courseId}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <Button
          variant="ghost"
          onClick={() => setLocation(`/teacher/courses/${params?.courseId}`)}
          className="mb-4"
          data-testid="button-back"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Course
        </Button>
        <h1 className="text-3xl font-bold" data-testid="text-page-title">Upload Course Material</h1>
        <p className="text-muted-foreground">Add learning resources for your students</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Material Details</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit((data) => uploadMaterialMutation.mutate(data))}
              className="space-y-4"
            >
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Material Title</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Week 1 Lecture Notes"
                        data-testid="input-title"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="fileUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>File URL</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="https://example.com/file.pdf"
                        data-testid="input-file-url"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Provide a direct link to the file (PDF, PPT, etc.)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="fileType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>File Type</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="PDF, PPT, DOCX, etc."
                        data-testid="input-file-type"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation(`/teacher/courses/${params?.courseId}`)}
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={uploadMaterialMutation.isPending}
                  data-testid="button-submit"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  {uploadMaterialMutation.isPending ? "Uploading..." : "Upload Material"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
